import torch.nn as nn


class Model(nn.Module):
    """
    ...
    """

    def __init__(self):
        super(Model, self).__init__()
        pass

    def positions(self, input_command, input_world_state):
        pass

